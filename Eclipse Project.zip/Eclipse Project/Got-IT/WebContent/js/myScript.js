function ajaxreq1(str,div)
{
	//alert('ajax');
	//document.getElementById("Result").innerHTML = "Loading Response...";
			if(window.XMLHttpRequest)
			{
				xmlhttp = new XMLHttpRequest();
			}
			xmlhttp.onreadystatechange = function()
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById(div).innerHTML = xmlhttp.responseText;
				}
			};
		//alert('req='+"controller.jsp?action="+str);
		xmlhttp.open("Post","controller.jsp?action="+str,true);
		xmlhttp.send();
		//$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
	    //$("[data-toggle='toggle']").bootstrapToggle();
		
}

function ajaxreq(str,div){
	//alert('ajax');
	$.ajax(
			{url: "controller.jsp?action="+str, 
				success: function(result){
					$("#"+div).html(result);
				}
			}
			);
}

function ajaxreq_success(str,div,fun){
	//alert('ajax');
	$.ajax(
			{url: "controller.jsp?action="+str, 
				success: function(result){
					$("#"+div).html(result);
					fun();
				}
			}
			);
}