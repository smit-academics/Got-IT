function ajaxreq1(str,div)
{
	//alert('ajax');
	//document.getElementById("Result").innerHTML = "Loading Response...";
			if(window.XMLHttpRequest)
			{
				xmlhttp = new XMLHttpRequest();
			}
			xmlhttp.onreadystatechange = function()
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById(div).innerHTML = xmlhttp.responseText;
				}
			};
		//alert('req='+"controller.jsp?action="+str);
		xmlhttp.open("Post","admincontroller.jsp?action="+str,true);
		xmlhttp.send();
		//$("[data-toggle='toggle']").bootstrapToggle('destroy');                 
	    //$("[data-toggle='toggle']").bootstrapToggle();
		
}

function ajaxreq(str,user,div){
	//alert('ajax');
	$.ajax(
			{url: "admincontroller.jsp?action="+str+"&user="+user, 
				success: function(result){
					$("#"+div).html(result);
				}
			}
			);
}