package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class URL extends DependencyInjected {
	String TableName="URLs";
	
	long url_id=-1;
	String protocol;
	String domain;
	String path;
	
	//--------------ID------------------
	public long getID(){
		return url_id;
	}
	public void setID(long e){
		url_id=e;
	}
	//-------------Protocol-------------
	public String getProtocol(){
		return protocol;
	}
	public void setProtocol(String e){
		protocol=e;
	}
	//----------------------------------
	//------------Domain----------------
	public String getDomain(){
		return domain;
	}
	public void setDomain(String e){
		domain=e;
	}
	//----------------------------------
	//----------------------------------
	public String getPath(){
		return path;
	}
	public void setPath(String e){
		path=e;
	}
	//----------------------------------
	//**********************************
	//----------------------------------
	public String toString(){
		return protocol+ "://" + domain + path;
	}
	public void reset(){
		url_id = -1;
		protocol = null;
		domain = null;
		path = null;
	}
	
	/** Create Operation: Inserts all Fields of URL Object into Database and also set url_id of inserted recoed in URL Object.
	*/
	public boolean addURL() throws SQLException{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ TableName +" values(default,?,?,?);" ,Statement.RETURN_GENERATED_KEYS);
		ps.setString(1,protocol);
		ps.setString(2,domain);
		ps.setString(3,path);
		
		int a = ps.executeUpdate();
		int id=-1;
		if(a==1){
			System.out.println("\nURL.SaveChanges() :Saved URL Changes Successfully");
			ResultSet rs = ps.getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            url_id = id;
            ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nURL.SaveChanges() :No URL Updated");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nURL.SaveChanges() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	/** Retrive Operation.
	 * @param id : takes primary key of URL tuple which is loaded in current instance of URL.
	 * @return true on success and false otherwise
	 * @throws SQLException
	 */
	public boolean loadURL(long id) throws SQLException{
		verifyConnection();
		url_id=id;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where url_id=?;");
		ps.setLong(1,url_id);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			protocol = rs.getString("protocol");
			domain = rs.getString("domain");
			path = rs.getString("path");
			System.out.println("\nSuccess :- URL : " + this.toString());
			ps.close();
			rs.close();
			return true;
		}
	}
	
	public boolean saveChanges() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("update "+ TableName +" set protocol=?,domain=?,path=? where url_id=?;");
		ps.setString(1,protocol);
		ps.setString(2,domain);
		ps.setString(3,path);
		ps.setLong(4,url_id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			System.out.println("\nURL.SaveChanges() :Saved URL Changes Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nURL.SaveChanges() :No URL Updated");
			return false;
		}
		else {
			System.out.println("\nURL.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean removeURL(long id) throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TableName +" where url_id=?;");
		ps.setLong(1,url_id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nURL.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nURL.remove() :No URL Deleted");
			return false;
		}
		else {
			System.out.println("\nURL.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
}
