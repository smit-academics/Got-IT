package model;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Resource extends DependencyInjected {
	private static final String TagMapTable = "taggings";
	private static final String TableName="res_descs";
	//private static final String TagsTable="Tags";
	long res_id;
	//long url_id;
	public model.URL url;
	String res_name;
	String res_desc;
	String res_type;
	String res_cat;
	int res_rat;
	String res_auth;
	Date res_date;
	String res_access;
	
	//-------------ID----------------
	public long getID(){
		return res_id;
	}
	public void setID(long e){
		res_id=e;
	}
	//--------------URL-------------
	public model.URL getURL(){
		return url;
	}
	public void setURL(model.URL e){
		url=e;
	}
	//------------Name---------------
	public String getName(){
		return res_name;
	}
	public void setName(String e){
		res_name=e;
	}
	//---------Description-----------
	public String getDescription(){
		return res_desc;
	}
	public void setDescription(String e){
		res_desc=e;
	}
	//------------Type---------------
	public String getType(){
		return res_type;
	}
	public void setType(String e){
		res_type=e;
	}
	//-----------Category------------
	public String getCategory(){
		return res_cat;
	}
	public void setCategory(String e){
		res_cat=e;
	}
	//-----------Rating--------------
	public int getRating(){
		return res_rat;
	}
	public void setRating(int e){
		res_rat=e;
	}
	//---------Author----------------
	public String getAuthor(){
		return res_auth;
	}
	public void setAuthor(String e){
		res_auth=e;
	}
	//--------Date-------------------
	public String getDate(){
		return res_date.toString();
	}

	public void setDate(String s) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/M/yyyy");
		String dateInString = s;
		java.util.Date date = sdf.parse(dateInString);
		res_date = new Date(date.getTime());
	    System.out.println(res_date);  
		
	}
	//---------Access----------------
	public String getAccess(){
		return res_access;
	}
	public void setAccess(String e){
		res_access=e;
	}
	//-------------------------------
	
	public boolean addResource() throws SQLException{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ TableName +" values(default,?,?,?,?,?,?,?,?,?);" ,Statement.RETURN_GENERATED_KEYS);
		ps.setLong(1,url.getID());
		ps.setString(2,res_name);
		ps.setString(3,res_desc);
		ps.setString(4,res_type);
		ps.setString(5,res_cat);
		ps.setInt(6,res_rat);
		ps.setString(7,res_auth);
		ps.setDate(8,res_date);
		ps.setString(9,res_access);
		
		int a = ps.executeUpdate();
		int id=-1;
		if(a==1){
			System.out.println("\nResource.addResource() :Inserted Successfully");
			ResultSet rs = ps.getGeneratedKeys();
            if(rs.next())
            {
                id = rs.getInt(1);
            }
            res_id = id;
            ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nResource.addResource() :Resource Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nResource.addResource() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	
	public boolean saveChanges() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("update "+ TableName +" set url_id=?,res_name=?,res_desc=?,res_type=?,res_cat=?,res_rat=?,res_auth=?,res_date=?,res_access=? where rd_id=?;");
		ps.setLong(1,url.url_id);
		ps.setString(2,res_name);
		ps.setString(3,res_desc);
		ps.setString(4,res_type);
		ps.setString(5,res_cat);
		ps.setInt(6,res_rat);
		ps.setString(7,res_auth);
		ps.setDate(8,res_date);
		ps.setString(9,res_access);
		ps.setLong(10,res_id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			System.out.println("\nResource.SaveChanges() :Saved Changes Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nResource.SaveChanges() :No Resource Updated");
			return false;
		}
		else {
			System.out.println("\nResource.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean removeResource(long id) throws SQLException{
		verifyConnection();
		System.out.println("model:res:res_id="+id);
		PreparedStatement ps = conn.prepareStatement("delete from "+ TableName +" where rd_id=?;");
		ps.setLong(1,res_id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nResource.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nResource.remove() :No Resource Deleted");
			return false;
		}
		else {
			System.out.println("\nResource.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	public boolean loadResource(long id) throws SQLException{
		verifyConnection();
		res_id=id;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where rd_id=?;");
		ps.setLong(1,res_id);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			url = new URL();
			url.conn = conn;
			url.loadURL(rs.getLong("url_id"));
			
			res_access = rs.getString("res_access");
			res_auth = rs.getString("res_auth");
			res_cat = rs.getString("res_cat");
			res_date = rs.getDate("res_date");
			res_desc = rs.getString("res_desc");
			res_name = rs.getString("res_name");
			res_rat = rs.getInt("res_rat");
			res_type = rs.getString("res_type");
			
			System.out.println("\nSuccess :- " + this.toString());
			ps.close();
			rs.close();
			return true;
		}
	}
	
	public void reset(){
		res_id = -1;
		res_access = null;
		res_auth = null;
		res_cat = null;
		res_date = null;
		res_desc = null;
		res_name = null;
		res_rat = -1;
		res_type = null;
	}
	
	//-----Foreign Operations--------------
	
	public boolean addTag(model.Tag t) throws SQLException{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ TagMapTable +" values(?,?);" ,Statement.RETURN_GENERATED_KEYS);
		ps.setLong(1,t.getID());
		ps.setLong(2,res_id);
		
		int a = ps.executeUpdate();
		
		if(a==1){
			System.out.println("\nResource.addTag() :Inserted Successfully");
			
			return true;
		} else if (a==0) {
			System.out.println("\nResource.addTag() :Tag Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nResource.addTag() :Something went Wrong!");
			ps.close();
			return false;
		}
		
	}
	
	public boolean removeAllTags() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TagMapTable +" where rd_id=?;");
		ps.setLong(1,res_id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nResource.removeAllTags() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nResource.removeAllTags() :No Tag Deleted");
			return false;
		}
		else {
			System.out.println("\nResource.removeAllTags() :Something went Wrong!");
			return false;
		}
	}
	//--------------------------------------------
	public static Resource[] getAllResources() throws SQLException{
		Resource r[] = new Resource[100];
		
		return r;
	}
	
}
