package model;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public abstract class DependencyInjected {
	public Connection conn;
	public HttpSession session;
	public HttpServletResponse response;
	
	public boolean isConnected(){
		if(conn != null){
			return true;
		}
		return false;
	}
	protected boolean isResponseSet() throws SQLException{
		if(response==null){
			return false;
		}
		return true;
	}
	protected boolean isSessionSet() throws SQLException{
		if(session==null){
			return false;
		}
		return true;
	}
	
	protected void verifyConnection() throws SQLException{
		if(!isConnected()){
			throw new SQLException("Not Connected Exception");
			//return false;
		}
	}
	public String hello()
	{
		return "Hello";
	}

}
