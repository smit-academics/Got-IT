package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class List extends DependencyInjected {
	private static final String ResMapTable = "list_items";
	String TableName="Lists";
	long id;
	String name;
	String description;
	String access;
	int rating;
	//---------------ID--------------
	public long getID(){
		return id;
	}
	public void setID(long e){
		id=e;
	}
	//-----------Name-----------------
	public String getName(){
		return name;
	}
	public void setName(String e){
		name=e;
	}
	//---------description------------
	public String getDescription(){
		return description;
	}
	public void setDescription(String e){
		description=e;
	}
	//----------Access----------------
	public String getAccess(){
		return access;
	}
	public void setAccess(String e){
		access=e;
	}
	//----------Rating----------------
	public int getRating(){
		return rating;
	}
	public void setRating(int e){
		rating=e;
	}
	
	public boolean addList() throws SQLException{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ TableName +" values(default,?,?,?,?);" ,Statement.RETURN_GENERATED_KEYS);
		ps.setString(1,name);
		ps.setString(2,description);
		ps.setString(3,access);
		ps.setInt(4,rating);
		
		int a = ps.executeUpdate();
		int ID=-1;
		if(a==1){
			System.out.println("\nList.addList() :Inserted Successfully");
			ResultSet rs = ps.getGeneratedKeys();
            if(rs.next())
            {
                ID = rs.getInt(1);
            }
            id = ID;
            ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nList.addList() :List Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nList.addList() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	public boolean saveChanges() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("update "+ TableName +" set list_name=?,list_desc=?,list_access=?,list_rat=? where list_id=?;");
		
		ps.setString(1,name);
		ps.setString(2,description);
		ps.setString(3,access);
		ps.setInt(4,rating);
		ps.setLong(5,id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			System.out.println("\nList.SaveChanges() :Saved Changes Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nList.SaveChanges() :No List Updated");
			return false;
		}
		else {
			System.out.println("\nList.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean removeList() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TableName +" where list_id=?;");
		ps.setLong(1,id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nList.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nList.remove() :No List Deleted");
			return false;
		}
		else {
			System.out.println("\nList.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean loadList(long ID) throws SQLException{
		verifyConnection();
		id=ID;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where list_id=?;");
		ps.setLong(1,id);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			access = rs.getString("list_access");
			description = rs.getString("list_desc");
			name = rs.getString("list_name");
			rating = rs.getInt("list_rat");
			
			System.out.println("\nSuccess :- " + this.toString());
			ps.close();
			rs.close();
			return true;
		}
	}
	public String toString(){
		return "List:-" + name;
	}
	
	public void reset(){
		id=-1;
		name=null;
		description=null;
		access=null;
		rating=-1;
	}
	
	//-----Foreign Operations--------------
	
		public boolean addResource(model.Resource r) throws SQLException{
			verifyConnection();
			PreparedStatement ps = conn.prepareStatement("insert into "+ ResMapTable +" values(?,?);");
			ps.setLong(1,id);
			ps.setLong(2,r.getID());
			System.out.println("id:"+ id +"\n"+"rid:"+r.getID());
			
			int a = ps.executeUpdate();
			
			if(a==1){
				System.out.println("\nList.addResource() :Inserted Successfully");
				
	            ps.close();
				return true;
			} else if (a==0) {
				System.out.println("\nList.addResource() :Tag Not Inserted");
				ps.close();
				return false;
			}
			else {
				System.out.println("\nList.addResource() :Something went Wrong!");
				ps.close();
				return false;
			}
			
		}
		public boolean removeAllResource() throws SQLException{
			verifyConnection();
			PreparedStatement ps = conn.prepareStatement("delete from "+ ResMapTable +" where list_id=?;");
			ps.setLong(1,id);
	
			int a = ps.executeUpdate();
			
			if(a==1){
				System.out.println("\nList.removeAllResource() :deleted Successfully");
				
	            ps.close();
				return true;
			} else if (a==0) {
				System.out.println("\nList.removeAllResource() :all items Not deleted");
				ps.close();
				return false;
			}
			else {
				System.out.println("\nList.removeAllResource() :Something went Wrong!");
				ps.close();
				return false;
			}
			
		}
}
