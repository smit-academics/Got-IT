package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Tag extends DependencyInjected {
	private static final String TagMapTable = "taggings";
	String TableName="Tags";
	long id;
	String label;
	
	
	//----------ID--------------
	public long getID(){
		return id;
	}
	public void setID(long e){
		id=e;
	}
	//-----------Name-----------------
	public String getLabel(){
		return label;
	}
	public void setLabel(String e){
		label=e;
	}
	public boolean addTag() throws SQLException{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ TableName +" values(default,?);" ,Statement.RETURN_GENERATED_KEYS);
		ps.setString(1,label);
		
		int a = ps.executeUpdate();
		int ID=-1;
		if(a==1){
			System.out.println("\nTag.addTag() :Inserted Successfully");
			ResultSet rs = ps.getGeneratedKeys();
            if(rs.next())
            {
                ID = rs.getInt(1);
            }
            id = ID;
            ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nTag.addTag() :List Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nTag.addTag() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	
	public boolean saveChanges() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("update "+ TableName +" set label=? where tag_id=?;");
		
		ps.setString(1,label);
		ps.setLong(2,id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			System.out.println("\nTag.SaveChanges() :Saved Changes Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nTag.SaveChanges() :No Tag Updated");
			return false;
		}
		else {
			System.out.println("\nTag.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean removeTag() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TableName +" where tag_id=?;");
		ps.setLong(1,id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nTag.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nTag.remove() :No Tag Deleted");
			return false;
		}
		else {
			System.out.println("\nTag.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	public boolean removeTaggings() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TagMapTable +" where tag_id=?;");
		ps.setLong(1,id);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nTagging.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nTagging.remove() :No Tag Deleted");
			return false;
		}
		else {
			System.out.println("\nTagging.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean loadTag(long ID) throws SQLException{
		verifyConnection();
		id=ID;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where tag_id=?;");
		ps.setLong(1,id);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			label = rs.getString("label");
			
			System.out.println("\nSuccess :- " + this.toString());
			ps.close();
			rs.close();
			return true;
		}
	}
	public boolean loadTag(String l) throws SQLException{
		verifyConnection();
		label=l;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where label=?;");
		ps.setString(1,l);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			//label = rs.getString("label");
			id = rs.getLong("tag_id");
			
			System.out.println("\nSuccess :- " + this.toString());
			ps.close();
			rs.close();
			return true;
		}
	}
	
	
	public String toString(){
		return "Tag:-" + label;
	}
	public void reset(){
		label = null;
		id = -1;
	}
	
}