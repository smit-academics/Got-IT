package model;

//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.Table;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.sql.*;
//import javax.servlet.http.*;
//@Entity
//@Table(name="User")

public class Admin extends DependencyInjected {
	private static final String CustTagMapTable = "cust_tags";
	private static final String ListOwnerMapTable = "list_owners";
	private static final String resOwnerMapTable = "res_owners";
	private static final String TableName = "Admins";
	
	//@Id
	//@Column(name="username")
	private String username;
	
	//@Column(name="password")
	private String password;
	
	//@Column(name="fname")
	private String firstname;
	
	//@Column(name="mname")
	private String middlename;
	
	//@Column(name="lname")
	private String lastname;
	
	//@Column(name="email",unique = true)
	private String email;
	
	private String country;
	private String state;
	private Date dob;
	
	//@Column(name="phone",unique = true)
	private String phone;
	
	//@Column(name="edu")	
	private int education;
	//DOB
	
	//-------------UserName------------------------
	public String getUserName(){
		return username;
	}
	public void setUserName(String un){
		username=un;
	}
	//-------------Password------------------------
	
	public String getPassword(){
		return password;
	}
	public void setPassword(String pass){
		password=pass;
	}
	//-------------FirstName------------------------
	
	public String getFirstName(){
		return firstname;
	}
	public void setFirstName(String fn){
		firstname=fn;
	}
	//-------------MiddleName------------------------
	
	public String getMiddleName(){
		return middlename;
	}
	public void setMiddleName(String mn){
		middlename=mn;
	}
	//-------------LastName------------------------
	
	public String getLastName(){
		return lastname;
	}
	public void setLastName(String ln){
		lastname=ln;
	}
	
	//-------------Email------------------------
	
	public String getEmail(){
		return email;
	}
	public void setEmail(String e){
		email=e;
	}
	//-------------Phone------------------------
	
	public String getPhone(){
		return phone;
	}
	public void setPhone(String p){
		phone=p;
	}
	//-------------Education------------------------
	
	public int getEducation(){
		return education;
	}
	public void setEducation(int e){
		education=e;
	}
	//-------------Country---------------------------
	public String getCountry(){
		return country;
	}
	public void setCountry(String c){
		country=c;
	}
	//-----------------State-------------------------
	public String getState(){
		return state;
	}
	public void setState(String s){
		state=s;
	}
	
	//-----------------DOB-------------------------
		public String getDOB(){
			return dob.toString();
		}

		public void setDOB(String s) throws ParseException{
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			String dateInString = s;
			java.util.Date date = sdf.parse(dateInString);
			dob = new Date(date.getTime());
		    System.out.println(dob);  
			
		}
	//-----------------------------------------------
	//-----------Registration Methods---------------------
	public boolean register() throws SQLException{
		verifyConnection();
		
		if(this.isRegistered()){
			System.out.println("Already Registered");
			return false;
		}
		else
		{
			
			PreparedStatement ps = conn.prepareStatement("insert into "+TableName +" values(?,?,?,?,?,?,?,?,?,?,?);");
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, firstname);
			ps.setString(4, middlename);
			ps.setString(5, lastname);
			ps.setString(6, email);
			ps.setString(7, phone);
			ps.setString(8, state);
			ps.setString(9, country);
			ps.setInt(10, education);
			ps.setDate(11, dob);
			
			int a = ps.executeUpdate();
			if(a==1){
				System.out.println("success");
				return true;
			}
			System.out.println("Update unsuccessful");
			return false;
		}
	}
	public boolean isRegistered() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("select * from "+TableName+" where username=? or email=? or phone=?;");
		ps.setString(1,username);
		ps.setString(2,email);
		ps.setString(3,phone);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			ps.close();
			return false;
		}
		else{
			ps.close();
			rs.close();
			return true;
		}
	}
	//-------------------------------------------------
	//-----------------Logging Methods-----------------
	public boolean isAuthenticAdmin() throws SQLException{
		verifyConnection();
		if(!isRegistered()){
			return false;
		}
		
		System.out.println("\nAdmin=" + username);
		PreparedStatement ps = conn.prepareStatement("select password from "+TableName +" where username=?;");
		ps.setString(1,username);
		ResultSet rs = ps.executeQuery();
		String p=null;
		while(rs.next()){
			p = rs.getString("password");
		}
		rs.close();
		ps.close();
		System.out.println("\npass=" + p);
		if( p.equals(password)){
			return true;
		}
		return false;
	}
	public boolean login() throws SQLException{
		verifyConnection();
		if(!isSessionSet() && !isResponseSet()){
			return false;
			//throw new Exception();
		}
		if(this.isAuthenticAdmin()){
			System.out.println("user = " + username);
			PreparedStatement ps = conn.prepareStatement("select fname from "+TableName +" where username=?;");
			ps.setString(1,username);
			ResultSet rs = ps.executeQuery();
			String fn=null;
			while(rs.next()){
				fn = rs.getString("fname");
			}
			session.setAttribute("user",username);
			session.setAttribute("user-FirstName",fn);
			session.setAttribute("userobj",this);
			
			rs.close();
			ps.close();
			return true;
		}
		return false;
	}
	public void logout() throws IOException, SQLException{
		if(!isSessionSet() && !isResponseSet()){
			//throw new Exception();
		}
		else{
		session.invalidate();
		}
	}
	
	public boolean loadAdmin(String uname) throws SQLException{
		verifyConnection();
		username = uname;
		PreparedStatement ps = conn.prepareStatement("select * from "+ TableName +" where username=?;");
		ps.setString(1,username);
		ResultSet rs = ps.executeQuery();
		if(!rs.next()){
			rs.close();
			ps.close();
			return false;
		}
		else{
			username = rs.getString("username");
			password = rs.getString("password");
			firstname = rs.getString("fname");
			middlename = rs.getString("mname");
			lastname = rs.getString("lname");
			email = rs.getString("email");
			phone = rs.getString("phone");
			state = rs.getString("state");
			country = rs.getString("country");
			education = rs.getInt("edu");
			dob = (java.sql.Date)rs.getDate("dob");
			
			System.out.println("\nfname :- " + firstname);
			System.out.println("\nSuccess :- " + this.toString());
			System.out.println("\ndob :- " + dob);
			ps.close();
			rs.close();
			return true;
		}
	}
	public String toString(){
		return "Admin User:-" + username;
	}
	
	public boolean saveChanges() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("update "+ TableName +" set password=?,fname=?,mname=?,lname=?,email=?,phone=?,state=?,country=?,edu=?,dob=? where username=?;");
		
		ps.setString(1,password);
		ps.setString(2,firstname);
		ps.setString(3,middlename);
		ps.setString(4,lastname);
		ps.setString(5,email);
		ps.setString(6,phone);
		ps.setString(7,state);
		ps.setString(8,country);
		ps.setInt(9,education);
		ps.setDate(10,dob);
		ps.setString(11,username);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			System.out.println("\nAdmin.SaveChanges() :Saved Changes Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.SaveChanges() :No User Updated");
			return false;
		}
		else {
			System.out.println("\nAdmin.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public boolean removeAdmin() throws SQLException{
		verifyConnection();
		
		PreparedStatement ps = conn.prepareStatement("delete from "+ TableName +" where username=?;");
		ps.setString(1,username);
		
		int a = ps.executeUpdate();
		ps.close();
		if(a==1){
			reset();
			System.out.println("\nList.remove() :Deleted Successfully");
			return true;
		} else if (a==0) {
			System.out.println("\nList.remove() :No List Deleted");
			return false;
		}
		else {
			System.out.println("\nList.SaveChanges() :Something went Wrong!");
			return false;
		}
	}
	
	public void reset(){
		username = null;
		password = null;
		firstname = null;
		middlename = null;
		lastname = null;
		email = null;
		phone = null;
		education = -1;
		country = null;
		state = null;
		dob = null;
	}
	
	//-----Foreign Operations--------------
	public boolean addCustomTag(model.Tag t, String usr) throws SQLException
	{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ CustTagMapTable +" values(?,?);");
		ps.setLong(1,t.getID());
		ps.setString(2,usr);
		System.out.println("Tagid:"+ t.getID() +"\n"+"Userid:"+ usr);
		
		int a = ps.executeUpdate();
		
		if(a==1){
			System.out.println("\nAdmin.addCustomTag() :Inserted Successfully");
			
          ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.addCustomTag() :Tag Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nAdmin.addCustomTag() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	public boolean removeCustomTag(model.Tag t, String user) throws SQLException
	{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("delete from "+ CustTagMapTable +" where tag_id=? and username=?");
		ps.setLong(1,t.getID());
		ps.setString(2,user);
		System.out.println("Tagid:"+ t.getID() +"\n"+"Userid:"+ user);
		
		int a = ps.executeUpdate();
		
		if(a==1){
			System.out.println("\nAdmin.removeCustomTag() :removed Successfully");
			
          ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.removeCustomTag() :Tag Not removed");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nAdmin.removeCustomTag() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	
	public boolean addList(List l, String user) throws SQLException
	{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ ListOwnerMapTable +" values(?,?);");
		ps.setString(1,user);
		ps.setLong(2,l.getID());
		System.out.println("\n"+"Userid:"+ user + "Listid:"+ l.getID());
		
		int a = ps.executeUpdate();
		
		if(a==1){
			System.out.println("\nAdmin.addList() :Inserted Successfully");
			
          ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.addList() : Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nAdmin.addList() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	
	public boolean addResource(Resource r, String user) throws SQLException
	{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("insert into "+ resOwnerMapTable +" values(?,?);");
		ps.setString(1,user);
		ps.setLong(2,r.getID());
		System.out.println("\n"+"Userid:"+ user + "Listid:"+ r.getID());
		
		int a = ps.executeUpdate();
		
		if(a==1){
			System.out.println("\nAdmin.addResource() :Inserted Successfully");
			
          ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.addResource() :Resource Not Inserted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nAdmin.addResource() :Something went Wrong!");
			ps.close();
			return false;
		}
	}
	
	public boolean removeResource(Resource r, String user) throws SQLException
	{
		verifyConnection();
		PreparedStatement ps = conn.prepareStatement("delete from "+ resOwnerMapTable +" where username=? and rd_id=?;");
		ps.setString(1,user);
		ps.setLong(2,r.getID());
		System.out.println("\n"+"Userid:"+ user + "resid:"+ r.getID());
		int a = ps.executeUpdate();
		if(a==1){
			System.out.println("\nAdmin.deleteResource() :deleted Successfully");
			
          ps.close();
			return true;
		} else if (a==0) {
			System.out.println("\nAdmin.deleteResource() :Resource Not deleted");
			ps.close();
			return false;
		}
		else {
			System.out.println("\nAdmin.deleteResource() :Something went Wrong!");
			ps.close();
			return false;
		}
	}

}